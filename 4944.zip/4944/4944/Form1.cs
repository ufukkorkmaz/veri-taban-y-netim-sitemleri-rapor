﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace _4944
{
    public partial class Form1 : Form
    {
        public void listele()
        
            listBox1.Items.Clear();
            NpgsqlConnection conn = new NpgsqlConnection("Server=localhost; Port=5432; Database=ufuk; User Id=postgres; Password=ufuk;");
            conn.Open();
            string sql = "SELECT \"urun_id\", \"urun_adi\",\"satis_fiyat\" FROM \"urun\"";
            // Define a query returning a single row result set
            NpgsqlCommand command = new NpgsqlCommand(sql, conn);

            NpgsqlDataReader dr = command.ExecuteReader();
            while (dr.Read())
            {
                listBox1.Items.Add(dr[0].ToString() + "-) " + dr[1].ToString() + " Fiyat:" + dr[2].ToString());

            }
            conn.Close();

        }
        public void ayrintili_listele(int id)
        {
            listBox2.Items.Clear();
            NpgsqlConnection conn = new NpgsqlConnection("Server=localhost; Port=5432; Database=ufuk; User Id=postgres; Password=ufuk;");
            conn.Open();
            string sql = "SELECT urun_adi,kategori_id,gelis_fiyat,satis_fiyat,tedarikci_id FROM urun WHERE urun_id='"+id+"'";
            // Define a query returning a single row result set
            NpgsqlCommand command = new NpgsqlCommand(sql, conn);

            NpgsqlDataReader dr = command.ExecuteReader();
            while (dr.Read())
            {
                listBox2.Items.Add(dr[0].ToString() + " " + " Kategori ID:" + dr[1].ToString() + " Geliş: " + dr[2].ToString() + " Gidiş " + dr[3].ToString() + " Tedarikçi ID: " + dr[4]);

            }
            conn.Close();

        }
        public void urun_ekle(string adi, int tedarikci, int satis_fiyat, int gelis_fiyat, int kategori_id)
        {
            NpgsqlConnection conn = new NpgsqlConnection("Server=localhost; Port=5432; Database=ufuk; User Id=postgres; Password=ufuk;");
            try { conn.Open(); } catch (Exception e) { }
            string sql = "INSERT INTO urun (urun_adi,tedarikci_id,satis_fiyat,gelis_fiyat,kategori_id) values ('" + adi + "','" + tedarikci + "','" + satis_fiyat + "','" + gelis_fiyat + "','" + kategori_id +"')";
            NpgsqlCommand cmd = new NpgsqlCommand(sql, conn);
            cmd.ExecuteNonQuery();
            conn.Close();
        }
        public void urun_guncelle(string adi, int gelis, int gidis,int id)
        {
            NpgsqlConnection conn = new NpgsqlConnection("Server=localhost; Port=5432; Database=ufuk; User Id=postgres; Password=ufuk;");
            try { conn.Open(); } catch (Exception e) { }

            string sql = "UPDATE \"urun\" SET \"urun_adi\"=\'" + adi + "\',\"gelis_fiyat\"=\'" + gelis + "\',\"satis_fiyat\"=\'" + gidis + "\' WHERE \"urun_id\"=\'" + id + "\'";
            NpgsqlCommand command = new NpgsqlCommand(sql, conn);
            command.ExecuteNonQuery();
            conn.Close();
        }
        public void urun_sil(int id)
        {
            NpgsqlConnection conn = new NpgsqlConnection("Server=localhost; Port=5432; Database=ufuk; User Id=postgres; Password=ufuk;");
            try { conn.Open(); } catch (Exception e) { }

            string sql = "DELETE FROM urun WHERE urun_id='" + id + "'";
            NpgsqlCommand command = new NpgsqlCommand(sql, conn);
            command.ExecuteNonQuery();
            conn.Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listele();
            comboBox1.Items.Add("Kardeşler Tedarik");
            comboBox1.Items.Add("Kuzenler Tedarik");
            comboBox1.Items.Add("Akrabalar Tedarik");

            comboBox2.Items.Add("Süt Ürünleri");
            comboBox2.Items.Add("Et");
            comboBox2.Items.Add("Baklagil");
            comboBox2.Items.Add("Temizlik");
            comboBox2.Items.Add("Atıştırmalık");
            comboBox2.Items.Add("İçecek");
            comboBox2.Items.Add("Şekerleme");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            urun_ekle(textBox1.Text, comboBox1.SelectedIndex + 1, Convert.ToInt32(numericUpDown3.Value), Convert.ToInt32(numericUpDown2.Value), comboBox2.SelectedIndex + 1);
            listele();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            urun_guncelle(textBox1.Text, Convert.ToInt32(numericUpDown3.Value), Convert.ToInt32(numericUpDown2.Value),Convert.ToInt32(numericUpDown1.Value));
            listele();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            urun_sil(Convert.ToInt32(numericUpDown1.Value));
            listele();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ayrintili_listele(Convert.ToInt32(numericUpDown1.Value));
            listele();
        }
    }
}
